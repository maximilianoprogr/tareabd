<form action="../php/registro_action.php" method="POST">
    <label for="userid">Usuario:</label>
    <input type="text" id="userid" name="userid" required>
    <br>
    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>
    <br>
    <input type="submit" value="Registrar">
</form>
